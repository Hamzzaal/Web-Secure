<?php
// verify_code.php

session_start();
include_once 'includes/db.php';
include_once 'includes/csrf.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_code = $_POST['verification_code'];

    // التحقق من تطابق الرمز المدخل مع الرمز المحفوظ في الجلسة
    if ($entered_code == $_SESSION['verification_code']) {
        // إذا تطابق الرمز، قم بتوجيه المستخدم إلى صفحة إعادة تعيين كلمة المرور
        header("Location: new_password.php");
        exit();
    } else {
        $message = "<div class='alert alert-danger text-center'>❌ Invalid verification code.</div>";
    }
}
?>

<?php include_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify Code - CyberSecurity Blog</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="container d-flex justify-content-center align-items-center" style="height: 80vh;">
    <div class="card p-5 shadow-lg text-center">
        <h2 class="mb-3">🔑 Verify Your Code</h2>
        <p class="text-muted mb-3">Enter the verification code sent to your email.</p>

        <?php echo $message; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Enter verification code</label>
                <input type="text" name="verification_code" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-warning w-100">Verify Code</button>
        </form>
    </div>
</div>
<?php include_once 'includes/footer.php'; ?>
</body>
</html>
