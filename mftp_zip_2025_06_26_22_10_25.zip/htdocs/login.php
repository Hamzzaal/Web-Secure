<?php
// login.php

// Force redirect to HTTPS if the connection is not secure
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $redirect = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: " . $redirect);
    exit();
}

session_start();
include_once 'includes/db.php'; // Connect to the database

// Temporarily disable CSRF for testing login without issues
// include_once 'includes/csrf.php';

// Ensure CSRF token is set if not already created
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Initialize error message
$error_message = "";

// Track number of login attempts
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

// Check if account is temporarily locked if login attempts exceeded
if (isset($_SESSION['login_block_time']) && time() < $_SESSION['login_block_time']) {
    $remaining_time = ceil(($_SESSION['login_block_time'] - time()) / 60);
    die("<div class='alert alert-warning text-center'>🚫 Your account is temporarily locked! Try again in {$remaining_time} minutes.</div>");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 🚨 Temporarily disabling CSRF for login testing
    // if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    //     die("<div class='alert alert-danger text-center'>❌ CSRF validation failed.</div>");
    // }

    // Check if email and password fields are empty
    if (empty($_POST['email']) || empty($_POST['password'])) {
        $error_message = "<div class='alert alert-danger text-center'>❌ Please enter both email and password.</div>";
    } else {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $password = htmlspecialchars($_POST['password']);

        try {
            // Secure query to fetch user data using email
            $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Check user credentials
            if ($user && password_verify($password, $user['password'])) {
                // Reset login attempts and remove block after successful login
                $_SESSION['login_attempts'] = 0;
                unset($_SESSION['login_block_time']);
                session_regenerate_id(true); // Regenerate session ID
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];

                // Debugging session data
                file_put_contents('session_debug.txt', print_r($_SESSION, true));

                // Redirect to the profile page
                header("Location: profile.php");
                exit();
            } else {
                // Increment failed login attempts
                $_SESSION['login_attempts']++;

                if ($_SESSION['login_attempts'] >= 3) {
                    $_SESSION['login_block_time'] = time() + (5 * 60);
                    die("<div class='alert alert-warning text-center'>🚫 Too many failed attempts. Please try again in 5 minutes.</div>");
                }

                $remaining_attempts = 3 - $_SESSION['login_attempts'];
                $error_message = "<div class='alert alert-danger text-center'>❌ Invalid email or password. Remaining attempts: {$remaining_attempts}.</div>";
            }
        } catch (PDOException $e) {
            die("<div class='alert alert-danger text-center'>❌ Database error: " . $e->getMessage() . "</div>");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Cyber Security Blog</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<?php include_once 'includes/header.php'; ?>

<div class="container d-flex justify-content-center align-items-center" style="height: 80vh;">
    <div class="card p-5 shadow-lg text-center">
        <h2 class="mb-3">🔐 Login to Your Account</h2>
        <p class="text-muted mb-3">Access your cybersecurity notes securely.</p>

        <?php echo $error_message; ?>

        <form method="POST" action="">
            <!-- 🚨 Temporarily disabled CSRF for login testing -->
            <!-- <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>"> -->

            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>

        <div class="text-center mt-3">
            <a href="reset_password.php">Forgot Password?</a>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>
</body>
</html>
