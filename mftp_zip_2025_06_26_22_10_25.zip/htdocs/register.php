<?php
// register.php

// فرض إعادة التوجيه إلى HTTPS إذا لم يكن الاتصال مشفرًا
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $redirect = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: " . $redirect);
    exit();
}

session_start();
include_once 'includes/header.php';
include_once 'includes/db.php';
include_once 'includes/csrf.php';

$error_message = "";
$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // التحقق من رمز CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("<div class='alert alert-danger'>❌ CSRF validation failed.</div>");
    }

    // تعقيم المدخلات
    $username = htmlspecialchars(trim($_POST['username']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // التحقق من تنسيق البريد الإلكتروني
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("<div class='alert alert-danger'>❌ Invalid email format.</div>");
    }

    // التحقق من صحة كلمة المرور:
    // - يجب أن تكون 8 أحرف على الأقل
    // - تحتوي على حرف كبير وحرف صغير ورقم واحد على الأقل
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password)) {
        die("<div class='alert alert-danger'>❌ Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, and one number.</div>");
    }

    // تجزئة كلمة المرور
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    // التحقق من وجود اسم المستخدم مسبقاً
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $error_message = "<div class='alert alert-danger'>❌ Username already exists. Please choose another one.</div>";
    }
    // التحقق من وجود البريد الإلكتروني مسبقاً
    elseif (($stmt = $conn->prepare("SELECT id FROM users WHERE email = :email")) &&
            $stmt->bindParam(':email', $email) &&
            $stmt->execute() &&
            $stmt->rowCount() > 0) {
        $error_message = "<div class='alert alert-danger'>❌ Email already registered.</div>";
    }
    else {
        // إدراج بيانات المستخدم في قاعدة البيانات
        $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password_hash);

        if ($stmt->execute()) {
            $success_message = "<div class='alert alert-success'>✅ Registration successful! <a href='login.php'>Login here</a>.</div>";
        } else {
            $error_message = "<div class='alert alert-danger'>❌ Registration failed. Please try again.</div>";
        }
    }
}
?>

<div class="container mt-5">
    <div class="card p-4 shadow-lg">
        <h2 class="text-center mb-4">Create a Secure Account</h2>
        <p class="text-center">Register now and start managing your cybersecurity notes securely.</p>

        <?php 
        if (!empty($error_message)) {
            echo $error_message;
        }
        if (!empty($success_message)) {
            echo $success_message;
        }
        ?>

        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
                <small class="text-muted">
                    Must be at least 8 characters, include uppercase, lowercase, and a number.
                </small>
            </div>

            <button type="submit" class="btn btn-primary w-100">Register</button>
        </form>

        <div class="text-center mt-3">
            <a href="login.php">Already have an account? Login here.</a>
        </div>
    </div>
</div>

<?php include_once 'includes/footer.php'; ?>
