<?php
// reset_password.php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'includes/PHPMailer/src/Exception.php';
require_once 'includes/PHPMailer/src/PHPMailer.php';
require_once 'includes/PHPMailer/src/SMTP.php';

// فرض HTTPS
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $redirect = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: " . $redirect);
    exit();
}

session_start();
include_once 'includes/db.php';
include_once 'includes/csrf.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // تحقق مما إذا كان البريد الإلكتروني موجودًا في قاعدة البيانات
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // إنشاء رمز تحقق عشوائي مكون من 6 أرقام
        $verification_code = rand(100000, 999999);

        // حفظ رمز التحقق في الجلسة (Session) للتحقق منه لاحقًا
        $_SESSION['verification_code'] = $verification_code;
        $_SESSION['email'] = $email;

        // إرسال البريد الإلكتروني باستخدام PHPMailer
        $mail = new PHPMailer(true);
        try {
            // إعدادات SMTP
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = '7.7hamza0@gmail.com'; // استبدل ببريدك الإلكتروني
            $mail->Password   = 'szhx kjaw vnog tgth'; // استبدل بكلمة مرور التطبيق
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            // إعدادات البريد الإلكتروني
            $mail->setFrom('7.7hamza0@gmail.com', 'CyberSecurity Blog');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Verification Code';
            $mail->Body    = "<p>Your verification code is: <strong>$verification_code</strong></p>";

            $mail->send();
            // توجيه المستخدم إلى صفحة التحقق من الرمز
            header("Location: verify_code.php");
            exit();
        } catch (Exception $e) {
            $message = "<div class='alert alert-danger text-center'>❌ Failed to send email. Mailer Error: {$mail->ErrorInfo}</div>";
        }
    } else {
        $message = "<div class='alert alert-danger text-center'>❌ No account found with that email.</div>";
    }
}
?>

<?php include_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password - CyberSecurity Blog</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="container d-flex justify-content-center align-items-center" style="height: 80vh;">
    <div class="card p-5 shadow-lg text-center">
        <h2 class="mb-3">🔑 Reset Your Password</h2>
        <p class="text-muted mb-3">Enter your email and we will send you a verification code.</p>

        <?php echo $message; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">Enter your email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-warning w-100">Send Verification Code</button>
        </form>
    </div>
</div>
<?php include_once 'includes/footer.php'; ?>
</body>
</html>