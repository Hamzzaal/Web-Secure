<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'includes/db.php';

if (isset($_GET['id'])) {
    $data_id = $_GET['id'];
    
    $stmt = $conn->prepare("DELETE FROM data_table WHERE id = ? AND user_id = ?");
    $stmt->bindValue(1, $data_id, PDO::PARAM_INT);
    $stmt->bindValue(2, $_SESSION['user_id'], PDO::PARAM_INT);
    $stmt->execute();
}

header("Location: data_management.php");
exit();
?>
