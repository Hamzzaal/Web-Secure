<?php
// profile.php

// تحويل الاتصال إلى HTTPS إذا لم يكن كذلك
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $redirect = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: " . $redirect);
    exit();
}

// بدء الجلسة والتحقق من وجود user_id
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// تضمين ملفات الاتصال بقاعدة البيانات والهيدر
include 'includes/db.php';
include 'includes/header.php';

// استعلام لاسترجاع بيانات المستخدم
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT username, email FROM users WHERE id = :id");
$stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

// دالة لإخفاء جزء من البريد الإلكتروني
function maskEmail($email) {
    $parts = explode("@", $email);
    $name = substr($parts[0], 0, 2) . str_repeat("*", strlen($parts[0]) - 2);
    return $name . "@" . $parts[1];
}

$masked_email = maskEmail($user['email']);
?>

<div class="container d-flex justify-content-center align-items-center" style="height: 80vh;">
    <div class="card p-5 shadow-lg text-center">
        <h2 class="mb-3">🎉 Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h2>
        <p class="text-muted mb-3">Your secure email: <strong><?php echo $masked_email; ?></strong></p>
        <a href="logout.php" class="btn btn-danger w-100">Logout</a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>