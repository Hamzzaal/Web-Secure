<?php
session_start();
include 'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recaptcha_secret = "6Lc2KcoqAAAAAMiaHprgD4ANhXiojBg6sNicrm0n"; // المفتاح السري
    $recaptcha_response = $_POST['g-recaptcha-response'];

    // تحقق من reCAPTCHA
    $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$recaptcha_secret}&response={$recaptcha_response}");
    $responseData = json_decode($verify);

    if (!$responseData->success) {
        echo "<div class='alert alert-danger'>❌ reCAPTCHA verification failed. Please try again.</div>";
        exit;
    }

    echo "<div class='alert alert-success'>✅ reCAPTCHA passed. Proceeding with login...</div>";

    // تابع عملية التحقق من بيانات المستخدم وتسجيل الدخول هنا...
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header("Location: profile.php");
        exit();
    } else {
        echo "<div class='alert alert-danger text-center'>❌ Invalid email or password.</div>";
    }
}
?>
