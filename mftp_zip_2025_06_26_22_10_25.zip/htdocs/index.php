<?php
// تأكد من أن الصفحة تُعرض عبر HTTPS، وإعادة التوجيه في حال لم يكن الاتصال مشفرًا
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $redirect = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: " . $redirect);
    exit();
}

// بعد التأكد من HTTPS، نقوم بتضمين ملفات header والصفحة
include 'includes/header.php';
?>

<div class="container text-center mt-5">
    <h1>Cyber Security Blog Manager</h1>
    <p>Store and manage your cybersecurity blogs and tools securely.</p>
    <a href="register.php" class="btn btn-primary">Get Started</a>
</div>

<?php include 'includes/footer.php'; ?>
