<?php
// includes/db.php
$servername = "sql102.infinityfree.com";  // حسب بيانات InfinityFree
$username   = "if0_38236144";              // اسم المستخدم الخاص بقاعدة البيانات
$password   = "hIFCxECeufZnh";             // كلمة المرور الخاصة بقاعدة البيانات
$dbname     = "if0_38236144_secure_app";    // اسم قاعدة البيانات

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
}
?>
