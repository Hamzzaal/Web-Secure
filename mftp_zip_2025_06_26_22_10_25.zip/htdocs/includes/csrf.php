<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if (!function_exists('getCsrfToken')) {
    function getCsrfToken() {
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('validateCsrfToken')) {
    function validateCsrfToken($token) {
        return hash_equals($_SESSION['csrf_token'], $token);
    }
}
?>









<!-- <?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?> -->
