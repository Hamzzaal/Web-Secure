<?php
// new_password.php

session_start();
include_once 'includes/db.php';
include_once 'includes/csrf.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // التحقق من تطابق كلمتي المرور
    if ($new_password === $confirm_password) {
        // تحديث كلمة المرور في قاعدة البيانات
        $email = $_SESSION['email'];
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("UPDATE users SET password = :password WHERE email = :email");
        $stmt->bindParam(':password', $hashed_password);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $message = "<div class='alert alert-success text-center'>✅ Password updated successfully.</div>";
    } else {
        $message = "<div class='alert alert-danger text-center'>❌ Passwords do not match.</div>";
    }
}
?>

<?php include_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New Password - CyberSecurity Blog</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="container d-flex justify-content-center align-items-center" style="height: 80vh;">
    <div class="card p-5 shadow-lg text-center">
        <h2 class="mb-3">🔑 Set New Password</h2>
        <p class="text-muted mb-3">Enter your new password.</p>

        <?php echo $message; ?>

        <form method="POST" action="">
            <div class="mb-3">
                <label class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-warning w-100">Reset Password</button>
        </form>
    </div>
</div>
<?php include_once 'includes/footer.php'; ?>
</body>
</html>