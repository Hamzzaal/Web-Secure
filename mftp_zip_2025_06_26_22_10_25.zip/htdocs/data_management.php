<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'includes/db.php';
$user_id = $_SESSION['user_id'];

// إعداد متغير الخطأ لعرضه داخل الصفحة
$error_message = "";

// ✅ **إضافة أو تحديث مدونة جديدة**
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['title'], $_POST['content'], $_POST['category'], $_POST['tags'], $_POST['csrf_token'])) {
    
    if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_message = "<div class='alert alert-danger'>❌ CSRF validation failed.</div>";
    } else {
        $title = htmlspecialchars(trim($_POST['title']));
        $content = htmlspecialchars(trim($_POST['content']));
        $category = $_POST['category'];
        $tags = htmlspecialchars(trim($_POST['tags']));

        // التحقق من طول البيانات لمنع الأخطاء
        if (strlen($title) < 3 || strlen($title) > 100) {
            $error_message = "<div class='alert alert-danger'>❌ Title must be between 3 and 100 characters.</div>";
        } elseif (strlen(trim($content)) < 10) {
            $error_message = "<div class='alert alert-danger'>❌ Content must be at least 10 characters long.</div>";
        } elseif (strlen($tags) > 255) {
            $error_message = "<div class='alert alert-danger'>❌ Tags must not exceed 255 characters.</div>";
        } else {
            if (isset($_POST['blog_id']) && !empty($_POST['blog_id'])) {
                // 🛑 **تحديث المدونة الموجودة**
                $blog_id = intval($_POST['blog_id']);
                $stmt = $conn->prepare("UPDATE data_table SET title = :title, content = :content, category = :category, tags = :tags WHERE id = :id AND user_id = :user_id");
                $stmt->bindParam(':id', $blog_id, PDO::PARAM_INT);
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->bindParam(':title', $title, PDO::PARAM_STR);
                $stmt->bindParam(':content', $content, PDO::PARAM_STR);
                $stmt->bindParam(':category', $category, PDO::PARAM_STR);
                $stmt->bindParam(':tags', $tags, PDO::PARAM_STR);
                $stmt->execute();
            } else {
                // ✅ **إدخال مدونة جديدة**
                $stmt = $conn->prepare("INSERT INTO data_table (user_id, title, content, category, tags) VALUES (:user_id, :title, :content, :category, :tags)");
                $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
                $stmt->bindParam(':title', $title, PDO::PARAM_STR);
                $stmt->bindParam(':content', $content, PDO::PARAM_STR);
                $stmt->bindParam(':category', $category, PDO::PARAM_STR);
                $stmt->bindParam(':tags', $tags, PDO::PARAM_STR);
                $stmt->execute();
            }
        }
    }
}

// ✅ **جلب المدونات الخاصة بالمستخدم فقط**
$stmt = $conn->prepare("SELECT id, title, content, category, tags FROM data_table WHERE user_id = :user_id");
$stmt->bindParam(":user_id", $user_id, PDO::PARAM_INT);
$stmt->execute();
$blogs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ✅ **جلب بيانات المدونة عند الضغط على "Edit"**
$edit_blog = null;
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $stmt = $conn->prepare("SELECT id, title, content, category, tags FROM data_table WHERE id = :id AND user_id = :user_id");
    $stmt->bindParam(':id', $edit_id, PDO::PARAM_INT);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $edit_blog = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<?php include 'includes/header.php'; ?>
<div class="container">
    <div class="card p-4 mt-4 shadow-lg">
        <h2 class="text-center">Manage Your Cybersecurity Blogs</h2>
        <p class="text-center">Document your tools, techniques, vulnerabilities, and findings.</p>

        <!-- عرض رسالة الخطأ داخل الصفحة -->
        <?php echo $error_message; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="blog_id" value="<?php echo $edit_blog ? $edit_blog['id'] : ''; ?>">

            <div class="mb-3">
                <label class="form-label">Blog Title</label>
                <input type="text" name="title" class="form-control" required value="<?php echo $edit_blog ? htmlspecialchars($edit_blog['title']) : ''; ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Content</label>
                <textarea name="content" class="form-control" required><?php echo $edit_blog ? htmlspecialchars($edit_blog['content']) : ''; ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Category</label>
                <select name="category" class="form-control">
                    <option value="Tools" <?php echo ($edit_blog && $edit_blog['category'] == 'Tools') ? 'selected' : ''; ?>>Tools</option>
                    <option value="Techniques" <?php echo ($edit_blog && $edit_blog['category'] == 'Techniques') ? 'selected' : ''; ?>>Techniques</option>
                    <option value="Threats" <?php echo ($edit_blog && $edit_blog['category'] == 'Threats') ? 'selected' : ''; ?>>Threats</option>
                    <option value="Vulnerabilities" <?php echo ($edit_blog && $edit_blog['category'] == 'Vulnerabilities') ? 'selected' : ''; ?>>Vulnerabilities</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Tags (comma-separated)</label>
                <input type="text" name="tags" class="form-control" required value="<?php echo $edit_blog ? htmlspecialchars($edit_blog['tags']) : ''; ?>">
            </div>

            <button type="submit" class="btn btn-<?php echo $edit_blog ? 'warning' : 'primary'; ?> w-100">
                <?php echo $edit_blog ? 'Update Blog' : 'Add Blog'; ?>
            </button>
        </form>

        <h3 class="mt-4">Your Blogs:</h3>
        <ul class="list-group">
            <?php foreach ($blogs as $blog): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <div>
                        <strong><?php echo htmlspecialchars($blog['title']); ?></strong> - <em><?php echo htmlspecialchars($blog['category']); ?></em>
                        <p><?php echo htmlspecialchars($blog['content']); ?></p>
                        <small>Tags: <?php echo htmlspecialchars($blog['tags']); ?></small>
                    </div>
                    <div>
                        <a href="data_management.php?edit_id=<?php echo $blog['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="delete_data.php?id=<?php echo $blog['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" class="btn btn-danger btn-sm">Delete</a>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
